﻿using System;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {
            if (File.Exists(@"C:\Users\bain_tseng\Desktop\TP\123.json"))
                File.Delete(@"C:\Users\bain_tseng\Desktop\TP\123.json");

            //MRC -> format
            var tfiles = Directory.GetFiles(@"C:\Users\bain_tseng\Desktop\TP\", "*.mrc");
            foreach (var filePath in tfiles)
            {
                //string filePath = @"C:\Users\bain_tseng\Desktop\TP\zone4_v2_15min.mrc";
                string fileContent = string.Empty;
                using (var objr = new StreamReader(filePath))
                {
                    fileContent = objr.ReadToEnd();
                }

                var tData = getTrainingData(fileContent);

                var resultData = new List<string>();

                for (int i = 0; i < tData.Count; i += 2)
                {
                    var tempReulst = parsingTrainingData(tData[i], tData[i + 1]);

                    resultData.Add(tempReulst);
                }

                var path = Path.GetDirectoryName(filePath) + "\\" + Path.GetFileNameWithoutExtension(filePath);
                using (var objw = new StreamWriter(path + ".format", false))
                {
                    resultData.ForEach(t => objw.WriteLine(t));
                }
            }


            //format -> JSON
            tfiles = Directory.GetFiles(@"C:\Users\bain_tseng\Desktop\TP\", "*.format");
            foreach (var filePath in tfiles)
            {
                string fileContent = string.Empty;

                using (var objr = new StreamReader(filePath))
                {
                    fileContent = objr.ReadToEnd();
                }
                JObject job = new JObject();
                JArray array = new JArray();

                foreach (var traingingData in fileContent.Split(new char[] { '\r', '\n' }, StringSplitOptions.RemoveEmptyEntries))
                {
                    var json = traingDataToJson(traingingData);

                    array.Add(json);
                }

                job.Add("Name", Path.GetFileNameWithoutExtension(filePath));

                job.Add("TrainingData", array);

                var path = Path.GetDirectoryName(filePath) + "\\" + Path.GetFileNameWithoutExtension(filePath);
                using (var objw = new StreamWriter(path + ".json", false))
                {
                    objw.WriteLine(JsonConvert.SerializeObject(job));
                }
            }


            //JSON Merge
            tfiles = Directory.GetFiles(@"C:\Users\bain_tseng\Desktop\TP\", "*.json");
            JArray jsonArray = new JArray();
            foreach (var filePath in tfiles)
            {
                string fileContent = string.Empty;

                using (var objr = new StreamReader(filePath))
                {
                    fileContent = objr.ReadToEnd();
                }

                var job = JObject.Parse(fileContent);

                jsonArray.Add(job);
            }

            using (var objw = new StreamWriter(@"C:\Users\bain_tseng\Desktop\TP\123.json", false))
            {
                objw.WriteLine(JsonConvert.SerializeObject(jsonArray));
            }
        }

        static List<string> getTrainingData(string fileContnet)
        {
            var contents = fileContnet.Split(new char[] { '\r', '\n' }, StringSplitOptions.RemoveEmptyEntries).ToList();

            var trainingData = new List<string>();

            int startIndex = contents.IndexOf("[COURSE DATA]") + 1;

            int endIndex = contents.IndexOf("[END COURSE DATA]");

            for (int i = startIndex; i < endIndex; i++)
            {
                trainingData.Add(contents[i]);
            }

            return trainingData;
        }

        static string parsingTrainingData(string from, string to)
        {
            var fromData = from.Split('\t');
            var toData = to.Split('\t');

            var fromTime = decimal.Parse(fromData[0]);
            var fromFTP = decimal.Parse(fromData[1]);

            var toTime = decimal.Parse(toData[0]);
            var toFTP = decimal.Parse(toData[1]);


            var traingTime = toTime - fromTime;

            decimal fraction = traingTime - Math.Floor(traingTime);

            var timeString = $"{traingTime}m";

            if (fraction != 0m)
            {
                timeString = $"{Math.Floor(traingTime)}m{Math.Floor(fraction * 60)}s";
            }


            return $"{fromFTP}% @ {timeString}";
        }

        static JObject traingDataToJson(string fileContnet)
        {
            var traingData = fileContnet.Split(new char[] { ' ', '@', ' ' }, StringSplitOptions.RemoveEmptyEntries);

            var ftp = traingData[0].Replace("%", "");
            var time = traingData[1];
            var training = decimal.Parse(ftp) / 100m;


            var json = new JObject();
            json.Add("ftp", training);
            json.Add("time", time);

            string color = "#3DB39F";
            if (training >= 0.56m && training <= 0.75m)
            {
                color = "#3DB33F";
            }
            else if (training >= 0.76m && training <= 0.9m)
            {
                color = "#FCD549";
            }
            else if (training >= 0.91m && training <= 1.05m)
            {
                color = "#FC9C49";
            }
            else if (training >= 1.06m && training <= 1.2m)
            {
                color = "#E34074";
            }
            else if (training >= 1.21m && training <= 1.5m)
            {
                color = "#8963D8";
            }
            json.Add("color", color);
            return json;
        }
    }
}